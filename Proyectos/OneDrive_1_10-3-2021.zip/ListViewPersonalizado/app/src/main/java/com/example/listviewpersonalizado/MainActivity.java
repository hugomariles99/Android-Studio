package com.example.listviewpersonalizado;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FrutasVerduras frutasVerduras_datos[]= new FrutasVerduras[]{
                new FrutasVerduras(R.mipmap.ic_launcher,"Manzana"),
                new FrutasVerduras(R.mipmap.ic_launcher,"Pepino"),
                new FrutasVerduras(R.mipmap.ic_launcher,"Pera"),
                new FrutasVerduras(R.mipmap.ic_launcher,"Naranja"),
                new FrutasVerduras(R.mipmap.ic_launcher,"Sandia"),
                new FrutasVerduras(R.mipmap.ic_launcher,"Lechuga"),
        };

        FrutasVerdurasAdapter adapter= new FrutasVerdurasAdapter(this, R.layout.listview_item_row, frutasVerduras_datos);

        lv=(ListView)findViewById(R.id.Lv);
        View header= (View)getLayoutInflater().inflate(R.layout.list_header,null);
        lv.addHeaderView(header);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                TextView v=(TextView)arg1.findViewById(R.id.tv);
                Toast.makeText(getApplicationContext(), v.getText(), Toast.LENGTH_SHORT).show();
            }
        });
    }

}
