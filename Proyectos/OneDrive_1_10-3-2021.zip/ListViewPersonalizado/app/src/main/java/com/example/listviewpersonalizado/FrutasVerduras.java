package com.example.listviewpersonalizado;

public class FrutasVerduras {
    public int icon;
    public String title;
    public FrutasVerduras(){
        super();
    }

    public FrutasVerduras(int icon, String title){
        super();
        this.icon=icon;
        this.title=title;
    }
}
